package com.example.sagarhomework.utilities;

public class NetworkUtils {

    public static void loadPosts() {

    }
}
